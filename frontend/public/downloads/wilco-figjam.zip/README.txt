ONE-TIME SETUP
1. In Figma desktop, choose Plugins > Development > New plugin. Name it Wilco meeting commands, choose FigJam, and save the generated folder. Figma assigns your development plugin ID.
2. Unzip this download. From this extracted folder run:
   python3 configure.py --from-manifest "/path/to/figma-generated/manifest.json"
   This updates only this bundle's manifest with your own Figma-issued ID.
3. Plugins > Development > Import plugin from manifest: select THIS bundle's updated manifest.json. Replace the previous development entry if Figma asks.
4. Open your FigJam file and run Wilco meeting commands. Paste that file's link and the one-time code from your Wilco live meeting. Keep the plugin open.

Use Figma Share to choose collaborators. Only the person hosting this plugin needs to install it. This development plugin is not published in Figma Community; your organization may require its approval. No Figma password or personal API key is requested.
